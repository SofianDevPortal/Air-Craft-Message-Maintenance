from __future__ import absolute_import, division, print_function
#import gensim.models.word2vec as w2v
from gensim.matutils import corpus2csc
from gensim.corpora import Dictionary
from gensim.models import Word2Vec
from sklearn.feature_extraction.text import CountVectorizer
import gensim.models.keyedvectors
from itertools import groupby
import logging
import itertools
#import nltk
#nltk.download('punkt')
from itertools import chain
#from nltk.tokenize import word_tokenize
from collections import Counter
from pprint import pprint
from itertools import combinations
import multiprocessing
from time import time
from collections import defaultdict
#from nltk import bigrams
import numpy as np
import pandas as pd
from sklearn import metrics
import sklearn.manifold
import sys
import sklearn.manifold
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt
import re
#import networkx as nx

#visualization
import seaborn as sns
# import glob
# import codecs
# import nltk
#import scipy

from co_occurence_matrix import generate_co_occurrence_matrix


logging.basicConfig(
    format='%(asctime)s : %(levelname)s : %(message)s',
    level=logging.INFO)

#df = pd.read_csv("training_set_corpus.csv", header=None, names = ['number'])
file1 = open("training_raw_data",'r')
#file2 = open("testing_set_corpus_ground_truth.txt",'r')



#print(df.keys())
#ans=list(df['number'])
#print(len(ans))
##print(ans)
#k=[]
#
#for i in range(len(ans)):
#     ans[i]=str(ans[i])
#
#     r = ans[i].split()
#     k.append(r)
#
#k.pop(0)
#print(len(k))
#print(k)
##
#final_list = [] #first three flight leg data
#final_list_1 = [] #test array for final_list
#final_list_2 = [] #4th flight leg data
#final_list_3 = []# test array for final_test_2
##A=[]
#C=[]
DataSet = []
Data = []
#
j = 0

       
#this for loop is to group 4 flight legs together - first three lists for maintenance message and fourth list for fde message. 
#first we start with outer for loop to add 4th flight leg. Inner loop is for 3 flight legs

#
#for i in range(3, len(k), 1):
#    j = i-3
#    while(j<i):
#        for item in k[j]:
##            if '-' in item:
#            final_list.append(item)
#        j+=1
#
##    for item in k[i]:
##            if '-' not in item:
##                final_list_2.append(item)
#
##    final_list_2.append(k[i])
#
#    pair = list(itertools.product(final_list, final_list_2))
#    for x in range(len(pair)):
#        pair[x] = list(pair[x])
#    print(pair)
#    for a in pair:
#        file1.write(a[0])
#        file1.write(" ")
#        file1.write(a[1])
#        file1.write(" ")
#    
#    final_list = []
##    final_list_2 = []
#    file1.write("\n")
#


        
for i in file1:
    DataSet.append(i)
for i in range(len(DataSet)):
    DataSet[i] = DataSet[i].replace('"',"")
    DataSet[i] = DataSet[i].replace("\n","")
    DataSet[i] = DataSet[i].split()


#
##co-occurence matrix
#data = list(itertools.chain.from_iterable(DataSet))
#matrix, vocab_index = generate_co_occurrence_matrix(data)
# 
# 
#data_matrix = pd.DataFrame(matrix, index=vocab_index,
#                             columns=vocab_index)
#
##print(data_matrix)
##data_matrix.to_csv('co_occurence_matrix_testing.csv')
#
#df= pd.read_csv('co_occurence_matrix_testing.csv', index_col=0)
#        
#for i in df:
#    if '-' in i:
#        df = df.drop(i, axis=0)
#        
#
#for column in df.columns[1:]:
#    if '-' not in column:
#        df = df.drop(column, axis=1)   
#
#df.to_csv('testing_coocurence_matrix.csv')
#
##READING FROM csv file to find out maximum co-occurence values
#df2= pd.read_csv('testing_coocurence_matrix.csv', index_col=0)
#
#maxValueIndex = df2.idxmax()
#
#maxValueIndex.to_csv('coocurence_analysis.csv')
#
#maxValuesMMSG = df2.max()
#
#
#df3 = pd.read_csv('ground_truth.txt')
#
#df1 = pd.read_csv("final_cooccurence.csv",index_col=0)
##df2 = pd.read_csv("final_coocurence2.csv",index_col=0)
#df3 = pd.read_csv("testing_coocurence_matrix.csv",index_col=0)
#
#
#
#required_fdes = []
#
#final100 = []
#
##df1 - modified ones
#
##
#for index1,row1 in df1.iterrows():
#    mmsg = index1
#    for col in df3:
#        if mmsg == col:
#            for index3,row3 in df3.iterrows():
#                if(df3[col][index3] > 50):
#                    required_fdes.append(index3)
#            final100.append([col] + required_fdes)
#            required_fdes = []


##Dimensionality of vectors
#num_features = 300
#
##Minimum word count
#min_word_count = 10
##
###Number of threads
cores = multiprocessing.cpu_count()
##
##Context window length
#context_size = 50
#
##downsample setting for frequent words
#
#downsampling = 6e-5
#
##seed for the RNG, reproducible
##deterministic, good for debugging
##helps us to choose a certain element and turn it into vector 
#seed = 0
#
#
##gensim
##very useful - similarity, training, loading and saving
##We basically built our model
#
#flight2vec = w2v.Word2Vec(
#        sg=1,
#        seed=seed,
#        workers=cores,
#        size=num_features,
#        min_count=min_word_count,
#        window=context_size,
#        sample=downsampling
##        
#        )

flight2vec = Word2Vec(
        min_count=10,
        window=50,
        size=300,
        sample=6e-5,
        alpha=0.03,
        min_alpha=0.0007,
        negative=20,
        workers=cores-1)


flight2vec.build_vocab(DataSet)

print("Word2Vec vocabulary length:", len(flight2vec.wv.vocab))

flight2vec.train(DataSet, total_examples=flight2vec.corpus_count, epochs=50)

#
flight_messages = list(flight2vec.wv.vocab)






#
#
def fde_result():
    #this is to ask for 2 mmsgs. I dont know if its right, so please check and let me know
              
        # taking multiple inputs at a time  
        # and type casting using list() function 
        print ("This function will print the relevant FDEs for MMSG inputs")
        
        x = input("Enter MMSG values: ").split(",")
        
        if len(x) > 8:
            print ("Error! Only 8 characters allowed!")
            sys.exit()
        
        a = MMSG(x)
        
        return a
#
def mmsg_result():
              
        # taking multiple inputs at a time
        # and type casting using list() function 
        print("This function will print the relevant MMSGs for FDE inputs")
        y = input("Enter FDE values: ").split(",")
    
#        
#        #If user doesnt type right stuff
#        if not re.match("^[1-9]-", x):
#            print("Error! Only numbers 1-9 allowed!")
#            sys.exit()
        #If user types in mmsg more than 8 characters 
        if len(y) > 8:
            print ("Error! Only 8 characters allowed!")
            sys.exit()
        
        b = FDE(y)
        
        return b
#    
def mmsg1_result():
    #this is to ask for 2 mmsgs. I dont know if its right, so please check and let me know
              
        # taking multiple inputs at a time  
        # and type casting using list() function 
        print("This function will print the relevant MMSGs for MMSG inputs")
        z = input("Enter MMSG values: ").split(",")
    
#        
#        #If user doesnt type right stuff
#        if not re.match("^[1-9]-", x):
#            print("Error! Only numbers 1-9 allowed!")
#            sys.exit()
        #If user types in mmsg more than 8 characters 
        if len(z) > 8:
            print ("Error! Only 8 characters allowed!")
            sys.exit()
        
        c = MMSG1(z)
        
        return c

def fde1_result():
    #this is to ask for 2 mmsgs. I dont know if its right, so please check and let me know
              
        # taking multiple inputs at a time  
        # and type casting using list() function 
        print("This function will print the relevant FDEs for FDE inputs")
        w = input("Enter FDE values: ").split(",")
    
#        
#        #If user doesnt type right stuff
#        if not re.match("^[1-9]-", x):
#            print("Error! Only numbers 1-9 allowed!")
#            sys.exit()
        #If user types in mmsg more than 8 characters 
        if len(w) > 8:
            print ("Error! Only 8 characters allowed!")
            sys.exit()
        
        d = FDE1(w)
        
        return d


        
        
#This prints fdes for mmsgs typed
def MMSG(e):
    
        FDE = flight2vec.wv.most_similar(positive=e)
#        for i in FDE:
#            if i not in FDE:
#                print("This maintenance message does not exist.")
        df = pd.DataFrame(FDE, columns = ['FDE', 'Cosine Similarity'])
        df = df[~df.FDE.str.contains("-")]
        #df = df.drop_duplicates()
        mmsg = print(df)
        return mmsg

#This prints mmsgs for fdes typed    
def FDE(f):
    
        MMSG = flight2vec.wv.most_similar(positive=f)
        df = pd.DataFrame(MMSG, columns = ['MMSG', 'Cosine Similarity'])
        df = df[df.MMSG.str.contains("-")]
        #df = df.drop_duplicates()
        fde = print(df)
        return fde

#this prints mmsgs for mmsgs typed
def MMSG1(g):
        MMSG1 = flight2vec.wv.most_similar(positive=g)

        df = pd.DataFrame(MMSG1, columns = ['MMSG1', 'Cosine Similarity'])
        df = df[df.MMSG1.str.contains("-")]
        
        mmsg1 = print(df)
        return mmsg1

#this prints fdes for fdes typed
def FDE1(h):
        FDE1 = flight2vec.wv.most_similar(positive=h)
        
        df = pd.DataFrame(FDE1, columns = ['FDE1', 'Cosine Similarity'])
        df = df[~df.FDE1.str.contains("-")]
        
        fde1= print(df)
        return fde1


#saving the model 
# I saved it as 'w2v_model.bin', I dunno if I saved it right,
        
def save_w2v():
    s = input("Enter a filename with .bin extension: ")
    model = flight2vec.wv.save_word2vec_format(s, binary=True)
    return model

#loading the model
def load_w2v():
    t = input("Enter a filename with .bin extension to load: ")
    model = gensim.models.KeyedVectors.load_word2vec_format(t, binary=True)
    return model


##T-SNE plot for visualization of vectors
#tsne = sklearn.manifold.TSNE(n_components=2, random_state=0)
#
#all_flight_vectors_matrix = flight2vec.wv.syn0
#
##train the tsne model
#all_flight_vectors_matrix_2d = tsne.fit_transform(all_flight_vectors_matrix)
#
#points = pd.DataFrame(
#        [
#                (num, coords[0], coords[1])
#                for num, coords in [
#                        (num,all_flight_vectors_matrix_2d[flight2vec.wv.vocab[num].index])
#                        for num in flight2vec.wv.vocab
#                ]
#        ]
#        ,columns=["num", "x", "y"]
#)
#
##Display the first few values from t-sne plot
#points.head(10)
#
#
#sns.set_context("poster")
#points.plot.scatter("x", "y", s=10, figsize=(20,12))
#def plot_region(x_bounds, y_bounds):
#    slice = points[
#    (x_bounds[0] <= points.x) &
#    (points.x <= x_bounds[1]) &
#    (y_bounds[0] <= points.y) &
#    (points.y <= y_bounds[1])
#    ]
#    ax = slice.plot.scatter("x", "y", s=35, figsize=(10,8))
#    for i, point in slice.iterrows():
#        ax.text(point.x + 0.005, point.y + 0.005, point.num, fontsize=11)
#
#plot_region(x_bounds=(0, 20), y_bounds=(0, 20))
#
#
#def nearest_similarity_cosmul(start1, end1, end2):
#    similarities = flight2vec.most_similar_cosmul(
#        positive=[end2, start1],
#        negative=[end1]
#    )
#    start2 = similarities[0][0]
#    print("{start1} is related to {end1}, as {start2} is related to {end2}".format(**locals()))
#    return start2

##nearest_similarity_cosmul("28-11036", "28202245", "31-69949")
#    
#
#
#
#
#
#    