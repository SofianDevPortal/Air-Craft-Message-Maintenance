import re  # For preprocessing
import pandas as pd  # For data handling
from time import time  # To time our operations
from collections import defaultdict  # For word frequency
import numpy as np
#import spacy  # For preprocessing
import multiprocessing
from gensim.models import Word2Vec, KeyedVectors
#import gensim.models.keyedvectors as word2vec
from gensim.test.utils import common_texts
import logging  # Setting up the loggings to monitor gensim
from random import sample
#import matplotlib.pyplot as plt
#from sklearn.decomposition import PCA
#import seaborn as sns
#from sklearn.manifold import TSNE

logging.basicConfig(format="%(levelname)s - %(asctime)s: %(message)s", datefmt= '%H:%M:%S', level=logging.INFO)
df = pd.read_csv('qcri_dataset_for_linux.csv', header=None, names = ['number'])

print(df.keys())
ans=list(df['number'])
print(len(ans))
print(ans)
k=[]

for i in range(len(ans)):
    r=(ans[i].split(','))
    for j in range(len(r)):
        r[j]=str(r[j])
        if (r[j][0]==''):
            r[j]=r[j][1:len(r[j])-1]
    k.append(r)

k.pop(0)
print(k)
#
#df['number']=k      
    
# for i in range(len(ans)):
# 	if (pd.isnull(ans[i])==0):
# 		k.append(ans[i])
# for i in range(len(k)):
# 	k[i]=((k[i]).split())

cores = multiprocessing.cpu_count()
w2v_model = Word2Vec(min_count=20,
                     window=2,
                     size=300,
                     sample=6e-5, 
                     alpha=0.03, 
                     min_alpha=0.0007,
                     negative=20,
                     workers=cores-1)
t = time()
w2v_model.build_vocab(k, progress_per=10000)
print('Time to build vocab: {} mins'.format(round((time() - t) / 60, 2)))
t = time()
w2v_model.train(k, total_examples=w2v_model.corpus_count, epochs=30, report_delay=1)
print('Time to train the model: {} mins'.format(round((time() - t) / 60, 2)))
w2v_model.init_sims(replace=True)

print(len(w2v_model.wv.vocab))

print(w2v_model.wv.vocab)


## fit a 2d PCA model to the vectors
#X = w2v_model[w2v_model.wv.vocab]
#pca = PCA(n_components=2)
#result = pca.fit_transform(X)
## create a scatter plot of the projection
#plt.scatter(result[:, 0], result[:, 1])
#words = list(w2v_model.wv.vocab)
#for i, word in enumerate(words):
#    plt.annotate(word, xy=(result[i, 0], result[i, 1]))
#plt.show()


#for i in w2v_model.wv.vocab:
#    print(i)
#    if '-' in i:
        
#        most_similars_precalc = {w2v_model.wv.most_similar(i) for i in w2v_model.wv.index2word}
#        df = 
    

#print(most_similars_precalc)

##for loading the data
#model = KeyedVectors.load_word2vec_format('w2v_model.bin', binary=True)
#
#
FDE = w2v_model.wv.most_similar(positive=["24-45490"])

#        
df = pd.DataFrame(FDE, columns = ['FDE', 'Cosine Similarity'])

df = df[~df.FDE.str.contains("-")]


#df = df.drop_duplicates()


print(df)

#MMSG = w2v_model.wv.most_similar(positive=[" 28202245", " 77330151", " 12400014", " 79332151"])
#
#df_1 = pd.DataFrame(MMSG, columns = ['MMSG', 'Cosine Similarity'])
#
#df_1 = df_1[df_1.MMSG.str.contains("-")]
#
#print(df_1)

#MMSG_ONLY = w2v_model.wv.most_similar(positive=["31-58013", "31-69949", "21-16301"])
#
##        
#df_2 = pd.DataFrame(MMSG_ONLY, columns = ['MMSG_ONLY', 'Cosine Similarity'])
#df_2 = df_2[df_2.MMSG_ONLY.str.contains("-")]
#
#print(df_2)

#FDE_ONLY = w2v_model.wv.most_similar(positive=[" 28202245", " 77330151", " 12400014"])
#df_3 = pd.DataFrame(FDE_ONLY, columns = ['FDE_ONLY', 'Cosine Similarity'])
#df_3 = df_3[~df_3.FDE_ONLY.str.contains("-")]
#
#print(df_3)
#def tsnescatterplot(model, word, list_names):
#    """ Plot in seaborn the results from the t-SNE dimensionality reduction algorithm of the vectors of a query word,
#    its list of most similar words, and a list of words.
#    """
#    arrays = np.empty((0, 300), dtype='f')
#    word_labels = [word]
#    color_list  = ['red']
#
#    # adds the vector of the query word
#    arrays = np.append(arrays, w2v_model.wv.__getitem__([word]), axis=0)
#    
#    # gets list of most similar words
#    close_words = w2v_model.wv.most_similar([word])
#    
#    # adds the vector for each of the closest words to the array
#    for wrd_score in close_words:
#        wrd_vector = w2v_model.wv.__getitem__([wrd_score[0]])
#        word_labels.append(wrd_score[0])
#        color_list.append('blue')
#        arrays = np.append(arrays, wrd_vector, axis=0)
#    
#    # adds the vector for each of the words from list_names to the array
#    for wrd in list_names:
#        wrd_vector = w2v_model.wv.__getitem__([wrd])
#        word_labels.append(wrd)
#        color_list.append('green')
#        arrays = np.append(arrays, wrd_vector, axis=0)
#        
#    # Reduces the dimensionality from 300 to 50 dimensions with PCA
#    reduc = PCA(n_components=50).fit_transform(arrays)
#    
#    # Finds t-SNE coordinates for 2 dimensions
#    np.set_printoptions(suppress=True)
#    
#    Y = TSNE(n_components=2, random_state=0, perplexity=15).fit_transform(reduc)
#    
#    # Sets everything up to plot
#    df = pd.DataFrame({'x': [x for x in Y[:, 0]],
#                       'y': [y for y in Y[:, 1]],
#                       'words': word_labels,
#                       'color': color_list})
#    
#    fig, _ = plt.subplots()
#    fig.set_size_inches(9, 9)
#    
#    # Basic plot
#    p1 = sns.regplot(data=df,
#                     x="x",
#                     y="y",
#                     fit_reg=False,
#                     marker="o",
#                     scatter_kws={'s': 40,
#                                  'facecolors': df['color']
#                                 }
#                    )
#    
#    # Adds annotations one by one with a loop
#    for line in range(0, df.shape[0]):
#         p1.text(df["x"][line],
#                 df['y'][line],
#                 '  ' + df["words"][line].title(),
#                 horizontalalignment='left',
#                 verticalalignment='bottom', size='medium',
#                 color=df['color'][line],
#                 weight='normal'
#                ).set_size(15)
#
#    
#    plt.xlim(Y[:, 0].min()-50, Y[:, 0].max()+50)
#    plt.ylim(Y[:, 1].min()-50, Y[:, 1].max()+50)
#            
#    plt.title('t-SNE visualization for {}'.format(word.title()))
#
#tsnescatterplot(w2v_model, '28-11036', ['28202145', '32408100', '32404200', '34431132', '22131300', '23202200', '32404100'])

#
###print("Most likely FDEs: ")        
###print(result)
#

#model = gensim.models.KeyedVectors.load('w2v_model.bin')

#def logistic_predictor_from_data(train_targets, train_regressors):
#    """Fit a statsmodel logistic predictor on supplied data"""
#    logit = sm.Logit(train_targets, train_regressors)
#    predictor = logit.fit(disp=0)
#    # print(predictor.summary())
#    return predictor
#
#def error_rate_for_model(test_model, train_set, test_set, 
#                         reinfer_train=False, reinfer_test=False, 
#                         infer_steps=None, infer_alpha=None, infer_subsample=0.2):
#    """Report error rate on test_doc sentiments, using supplied model and train_docs"""
#
#    train_targets = [doc.sentiment for doc in train_set]
#    if reinfer_train:
#        train_regressors = [test_model.infer_vector(doc.words, steps=infer_steps, alpha=infer_alpha) for doc in train_set]
#    else:
#        train_regressors = [test_model.docvecs[doc.tags[0]] for doc in train_set]
#    train_regressors = sm.add_constant(train_regressors)
#    predictor = logistic_predictor_from_data(train_targets, train_regressors)
#
#    test_data = test_set
#    if reinfer_test:
#        if infer_subsample < 1.0:
#            test_data = sample(test_data, int(infer_subsample * len(test_data)))
#        test_regressors = [test_model.infer_vector(doc.words, steps=infer_steps, alpha=infer_alpha) for doc in test_data]
#    else:
#        test_regressors = [test_model.docvecs[doc.tags[0]] for doc in test_docs]
#    test_regressors = sm.add_constant(test_regressors)
#    
#    # Predict & evaluate
#    test_predictions = predictor.predict(test_regressors)
#    corrects = sum(np.rint(test_predictions) == [doc.sentiment for doc in test_data])
#    errors = len(test_predictions) - corrects
#    error_rate = float(errors) / len(test_predictions)
#    return (error_rate, errors, len(test_predictions), predictor)
#
#error_rates = defaultdict(lambda: 1.0)  # To selectively print only best errors achieved
#
#for model in simple_models: 
#    print("Training %s" % model)
#    model.train(doc_list, total_examples=len(doc_list), epochs=model.epochs)
#    
#    print("\nEvaluating %s" % model)
#    err_rate, err_count, test_count, predictor = error_rate_for_model(model, train_docs, test_docs)
#    error_rates[str(model)] = err_rate
#    print("\n%f %s\n" % (err_rate, model))



