#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 12 03:02:07 2019

@author: qcri
"""
import pprint
file1 = open("data_file.csv","r")
file2 = open("corp.csv","a")

for i in file1:
    i = i.replace(","," ")
    i = i.replace("  "," ")
    i = i.replace('"',"")
    print(i)
    file2.write(i)
#    print("\n")

file1.close()
file2.close()