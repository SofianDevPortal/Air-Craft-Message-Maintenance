from word2vec_gensim_working import load_w2v
import sys
import pandas as pd
from gensim.matutils import corpus2csc
from gensim.corpora import Dictionary
import matplotlib.pyplot as plt
#visualization
import seaborn as sns
#import glob
#import codecs
#import nltk
import sklearn.manifold
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
#import tkinter
#from tkinter import *
#from tkinter import ttk 
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.metrics import precision_score, recall_score, make_scorer
from PyQt5 import QtCore, QtGui


flight2vec = load_w2v()

def fde_result(*args):
    #this is to ask for 2 mmsgs. I dont know if its right, so please check and let me know
              
        # taking multiple inputs at a time  
        # and type casting using list() function
        for a in args:
            
            print ("This function will print the relevant FDEs for MMSG inputs")
        
#        x = input("Enter MMSG values: ").split(",")
        
            if len(a) > 8:
                print ("Error! Only 8 characters allowed!")
                sys.exit()
        
            result = MMSG(a)
        
            return result
#
def mmsg_result(*args):
    #this is to ask for 2 mmsgs. I dont know if its right, so please check and let me know
              
        # taking multiple inputs at a time  
        # and type casting using list() function
        for a in args:
            
            print ("This function will print the relevant FDEs for MMSG inputs")
        
#        x = input("Enter MMSG values: ").split(",")
        
            if len(a) > 8:
                print ("Error! Only 8 characters allowed!")
                sys.exit()
        
            result = FDE(a)
        
            return result

def mmsg1_result(*args):
    #this is to ask for 2 mmsgs. I dont know if its right, so please check and let me know
              
        # taking multiple inputs at a time  
        # and type casting using list() function
        for a in args:
            
            print ("This function will print the relevant FDEs for MMSG inputs")
        
#        x = input("Enter MMSG values: ").split(",")
        
            if len(a) > 8:
                print ("Error! Only 8 characters allowed!")
                sys.exit()
        
            result = MMSG1(a)
        
            return result


def fde1_result(*args):
    #this is to ask for 2 mmsgs. I dont know if its right, so please check and let me know
              
        # taking multiple inputs at a time  
        # and type casting using list() function
        for a in args:
            
            print ("This function will print the relevant FDEs for MMSG inputs")
        
#        x = input("Enter MMSG values: ").split(",")
        
            if len(a) > 8:
                print ("Error! Only 8 characters allowed!")
                sys.exit()
        
            result = FDE1(a)
        
            return result
               
#This prints fdes for mmsgs typed
def MMSG(e):
    
        FDE = flight2vec.wv.most_similar(positive=e)
        df = pd.DataFrame(FDE, columns = ['FDE', 'Cosine Similarity'])
        df = df[~df.FDE.str.contains("-")]
        #df = df.drop_duplicates()
        mmsg = print(df)
        return mmsg

#This prints mmsgs for fdes typed    
def FDE(f):
    
        MMSG = flight2vec.wv.most_similar(positive=f)
        df = pd.DataFrame(MMSG, columns = ['MMSG', 'Cosine Similarity'])
        df = df[df.MMSG.str.contains("-")]
        #df = df.drop_duplicates()
        fde = print(df)
        return fde

#this prints mmsgs for mmsgs typed
def MMSG1(g):
        MMSG1 = flight2vec.wv.most_similar(positive=g)

        df = pd.DataFrame(MMSG1, columns = ['MMSG1', 'Cosine Similarity'])
        df = df[df.MMSG1.str.contains("-")]
        
        mmsg1 = print(df)
        return mmsg1

#this prints fdes for fdes typed
def FDE1(h):
        FDE1 = flight2vec.wv.most_similar(positive=h)
        
        df = pd.DataFrame(FDE1, columns = ['FDE1', 'Cosine Similarity'])
        df = df[~df.FDE1.str.contains("-")]
        
        fde1= print(df)
        return fde1


#class Window(QtGui.QWidget):
#    def __init__(self):
#        QtGui.QWidget.__init__(self)
#        self.ui = Ui_Window()
#        self.ui.setupUi(self)
#        self.ui.pushButton.clicked.connect(self.handleQuery)
#
#    def handleQuery(self):
#        
#        
#
#if __name__ == '__main__':
#    app = QtGui.QApplication(sys.argv)
#    window = Window()
#    window.show()
#    sys.exit(app.exec_())
        
    





















##T-SNE plot for visualization of vectors
#tsne = sklearn.manifold.TSNE(n_components=2, random_state=0)
#
#all_flight_vectors_matrix = flight2vec.wv.syn0
#
##train the tsne model
#all_flight_vectors_matrix_2d = tsne.fit_transform(all_flight_vectors_matrix)
#
#points = pd.DataFrame(
#        [
#                (num, coords[0], coords[1])
#                for num, coords in [
#                        (num,all_flight_vectors_matrix_2d[flight2vec.wv.vocab[num].index])
#                        for num in flight2vec.wv.vocab
#                ]
#        ]
#        ,columns=["num", "x", "y"]
#)
#
##Display the first few values from t-sne plot
#points.head(10)
#
#
#sns.set_context("poster")
#points.plot.scatter("x", "y", s=10, figsize=(20,12))
#def plot_region(x_bounds, y_bounds):
#    slice = points[
#    (x_bounds[0] <= points.x) &
#    (points.x <= x_bounds[1]) &
#    (y_bounds[0] <= points.y) &
#    (points.y <= y_bounds[1])
#    ]
#    ax = slice.plot.scatter("x", "y", s=35, figsize=(10,8))
#    for i, point in slice.iterrows():
#        ax.text(point.x + 0.005, point.y + 0.005, point.num, fontsize=11)
#
#plot_region(x_bounds=(0, 20), y_bounds=(0, 20))
#
#
#def nearest_similarity_cosmul(start1, end1, end2):
#    similarities = flight2vec.most_similar_cosmul(
#        positive=[end2, start1],
#        negative=[end1]
#    )
#    start2 = similarities[0][0]
#    print("{start1} is related to {end1}, as {start2} is related to {end2}".format(**locals()))
#    return start2

# This is needed to make sentence vectors from word2vec embeddings using the averaging methods
#result = [c for c in DataSet_train[0]]


#text_vector = np.mean([flight2vec[word] for word in DataSet_train], axis=0)
#
#print(text_vector)
#  
#def vec_for_learning(model, tagged_docs):
#    x = dict(tagged_docs)
#    sents = x.values
#    targets, regressors = zip(*[(doc.tags[0], model.infer_vector(doc.words, steps=20)) for doc in sents])
#    
#    return targets, regressors
#
#y_train, X_train = vec_for_learning(flight2vec, DataSet_train)
#y_test, X_test = vec_for_learning(flight2vec, DataSet_test)
#
#logreg = LogisticRegression(n_jobs=1, C=1e5)
#logreg.fit(X_train, y_train)
#y_pred = logreg.predict(X_test)
#
#from sklearn.metrics import accuracy_score, f1_score
#
#print('Testing accuracy %s' % accuracy_score(y_test, y_pred))
#print('Testing F1 score: {}'.format(f1_score(y_test, y_pred, average='weighted')))
#
##metrics library
#cnf_matrix = metrics.confusion_matrix(y_test, y_pred)
#print(cnf_matrix)
#
##to visualize the confusion matrix using heatmap
#class_names=[0,1] # name  of classes
#fig, ax = plt.subplots()
#tick_marks = np.arange(len(class_names))
#plt.xticks(tick_marks, class_names)
#plt.yticks(tick_marks, class_names)
## create heatmap
#sns.heatmap(pd.DataFrame(cnf_matrix), annot=True, cmap="YlGnBu" ,fmt='g')
#ax.xaxis.set_label_position("top")
#plt.tight_layout()
#plt.title('Confusion matrix', y=1.1)
#plt.ylabel('Actual label')
#plt.xlabel('Predicted label')
    
    
    
#rw = Tk()
#
#
## def printSomething():
##     # if you want the button to disappear:
##     # button.destroy() or button.pack_forget()
##     label = Label(rw, text= "Hey whatsup bro, i am doing something very interresting.")
##     #this creates a new label to the GUI
##     label.pack()
#
#
#
#
#btn1 = ttk.Button(rw,text="MMSG -> FDE")
#btn1.pack()
#btn1.config(command=fde_result)
#
#btn2 = ttk.Button(rw,text="FDE -> MMSG")
#btn2.pack()
#btn2.config(command=mmsg_result)
#
#btn3 = ttk.Button(rw,text="MMSG -> MMSG")
#btn3.pack()
#btn3.config(command=mmsg1_result)
#
#btn4 = ttk.Button(rw,text="FDE -> FDE")
#btn4.pack()
#btn4.config(command=fde1_result)



