from itertools import groupby
import logging
import itertools
#import nltk
#nltk.download('punkt')
from itertools import chain
#from nltk.tokenize import word_tokenize
#from collections import Counter
from pprint import pprint
from itertools import combinations
import multiprocessing
from time import time
from collections import defaultdict
#from nltk import bigrams
import numpy as np
import pandas as pd





logging.basicConfig(
    format='%(asctime)s : %(levelname)s : %(message)s',
    level=logging.INFO)

file3 = open("training_set_corpus.csv",'r')
file4 = open("training_raw_data","a")


temp = []  
temp2 = []  
for i in file3:
    temp.append(i.split("\n"))
for i in range(len(temp)):
    temp[i].remove('')

for l in range(16531,len(temp)+1,1):
    for i in range(l-3,l):
        k = temp[i][0].split()
        for a in k:
#            if '-' in a:
            file4.write(a)
            file4.write(" ")
    file4.write("\n")
